exports.SECRET = '0160e01a-f5d9-4af3-9808-891e0c3c5cc7';
exports.TOKEN_KEY = 'token';