const Offer = require('../models/Offer');

exports.getAll = () => Offer.find();

exports.getOne = (offerId) => Offer.findById(offerId).populate('owner');

exports.create = (offerData) => Offer.create(offerData);

exports.delete = (offerId) => Offer.findByIdAndDelete(offerId);

exports.edit = (offerId, offerData) => Offer.findByIdAndUpdate(offerId,offerData);

exports.getByOwner = (userId) => Offer.find({owner: userId});