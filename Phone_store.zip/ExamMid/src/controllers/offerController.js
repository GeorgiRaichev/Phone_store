const router = require('express').Router();
const offerManager = require('../managers/offerManager');
const {getErrorMessage} = require('../utils/errorHelpers')

router.get('/', async (req, res) => {
    const offers = await offerManager.getAll().lean();
    res.render('offers', {offers});
});

router.get('/create', (req, res) => {
    res.render('offers/create')
});

router.post('/create', async (req, res) => {
    const offerData = {
        ...req.body,
        owner: req.user._id,
    };
    try {
        await offerManager.create(offerData);
        res.redirect('/offers');
    } catch (err) {
        res.render('offers/create', {error: getErrorMessage(err)});
    }
    
});

router.get('/:offersId/details', async (req, res) => {
    try {
        
    } catch (error) {
        
    }
    const offerId = req.params.offersId;
    const offer = await offerManager.getOne(offerId).lean();
    const isOwner = req.user?._id == offer.owner?._id;
    const dali = req.user?._id!=undefined;
    res.render('offers/details', {offer, isOwner,dali});
});


router.get('/:offerId/delete', async (req, res) => {
    const offerId = req.params.offerId;
    try {
        await offerManager.delete(req.params.offerId);
        res.redirect('/offers');
    } catch (err) {
        res.render(`/offers/details`, {error: 'Unsuccesfull deletion!'});
    }
    
});

router.get('/:offerId/edit', async (req, res) => {
    try {
        const offer = await offerManager.getOne(req.params.offerId).lean();
        res.render('offers/edit',{offer});
        //res.redirect('/offers');
    } catch (err) {
        res.render(`/offers/details`, {error: 'Unsuccesfull edit!'});
    }
    
});

router.post('/:offerId/edit', async (req, res) => {
    const offerData = req.body;
    const offerId = req.params.offerId;
    try {
        
    await offerManager.edit(req.params.offerId, offerData);

    res.redirect(`/offers/${offerId}/details`);
    } catch (err) {
        res.render('offer/edit', {error: 'Unable to update post!', ...offerData});
    }
    
});
/*
router.post('/:offerId/buy', async (req, res) =>{

   
    const offerId = req.params.offerId;
    const userId = req.user._id;
    

    res.redirect(`offers/${offerId}/details`);
});
*/
module.exports = router;
